class King < Person
	
	def initialize
		super()
		@PowerInterface.setStatus(15,4,0.05)
		
	end
end