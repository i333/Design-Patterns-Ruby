class Bandit < Person
	
	def initialize
		super()
		@PowerInterface.setStatus(12,3,0.02)
		
	end
end