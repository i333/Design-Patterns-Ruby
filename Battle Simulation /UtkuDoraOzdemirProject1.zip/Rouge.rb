class Rouge < Person
	def initialize
		super()
		@PowerInterface.setStatus(8,4,0.3)
	end
end