class Wariror < Person
	def initialize
		super()
		@PowerInterface.setStatus(15,3,0.1)
	end
end