
class Thief< Person
	
	def initialize
		super()
		@PowerInterface.setStatus(5,3,0.8)
		
	end
end